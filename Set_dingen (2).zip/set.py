import pygame
import random

pygame.init()
screen = pygame.display.set_mode((1000,600))
pygame.display.set_caption('Set')
clock = pygame.time.Clock()

#images
start_img = pygame.image.load('knoppen/startbutton.png').convert_alpha()
exit_img = pygame.image.load('knoppen/exitbutton.png').convert_alpha()
background = pygame.image.load('miscellaneous/bg.png').convert_alpha()
title = pygame.image.load('miscellaneous/title.png').convert_alpha()
title = pygame.transform.scale(title, (500, 200))
slctbord = pygame.image.load('miscellaneous/selected.png').convert_alpha()
hintknop = pygame.image.load('knoppen/hintknop.png').convert_alpha()
cheatknop = pygame.image.load('knoppen/cheat.png').convert_alpha()
home = pygame.image.load('knoppen/home.png').convert_alpha()
easy = pygame.image.load('knoppen/easy.png').convert_alpha()
normal = pygame.image.load('knoppen/normal.png').convert_alpha()
hard = pygame.image.load('knoppen/hard.png').convert_alpha()
htp = pygame.image.load('knoppen/howtoplay.png').convert_alpha()
tut = pygame.image.load('miscellaneous/tutorial.png').convert_alpha()
walt  = pygame.image.load('miscellaneous/walticon.png').convert_alpha()
#font
font = pygame.font.Font('miscellaneous/seguisb.ttf', 35)

#button class
class Button:
    def __init__(self, image, x, y, scale, enabled):        #initieerd alle variabelen en scaled image 
        self.x = x
        self.y = y
        self.scale = scale
        width = image.get_width() 
        height = image.get_height()        
        self.width = width * scale
        self.height = height * scale
        self.image = pygame.transform.scale(image, (int(self.width), int(self.height)))
        self.rect = self.image.get_rect()
        self.enabled = enabled
        self.draw()

    def draw(self):                                         #zorgt ervoor dat de image geblit word
        screen.blit(self.image, (self.x, self.y))

    def check_click(self):                                  #maakt rect op de positie van image, en checkt of er geklikt wordt.
        mouse_pos = pygame.mouse.get_pos()
        left_click = pygame.mouse.get_pressed()[0]
        button_rect = pygame.rect.Rect((self.x, self.y), (self.width, self.height))
        if left_click and button_rect.collidepoint(mouse_pos) and self.enabled:
            return True
        else:
            return False

#kaartenlader:
cards = {}
for color in ['green','purple','red']:
       for shape in ['diamond','oval','squiggle']:
           for infill in ['empty', 'filled', 'shaded']:
               for value in '123':      
                    cards[color + shape + infill + value] = pygame.image.load('kaarten/'+ color + shape + infill + value +'.gif').convert_alpha()  
cards.update({'leeg':pygame.image.load('miscellaneous/empty.png').convert_alpha()})

#hintgetallader:
hints = {}
for getal in ['1','2','3','4','5','6','7','8','9','10','11','12']:
    hints[getal] = pygame.image.load('antwoord/'+getal+'.png').convert_alpha()

#dicts, variablen en lijsten die gebruikt gaan worden
kleur = {0: 'green', 1: 'purple', 2: 'red'}
vorm = {0: 'diamond', 1: 'oval', 2: 'squiggle'}
vulling = {0: 'empty', 1: 'filled', 2: 'shaded'}
waarde = {0: '1', 1: '2' ,2: '3'}
converter = {'green':0,'purple':1,'red':2,'diamond':0, 'oval': 1,'squiggle':2, 'empty':0,'filled':1,'shaded':2,'1':0,'2':1,'3':2,'leeg' :20}
selectdict = {}     
hintdict = {}
puntenspeler = 0
puntenai = 0
selectint = 1       #wordt later gebruikt om selectdict en hintdict aan te maken
timx = 0            #wordt gebruikt voor de timer, letterlijk timer pos x
run = True
insel= []           #index van geselecteerde kaart                       
selected = []       #lijst met geselecteerde kaarten
pos =[]             #lijst met kaarten op de positie van het bord
kaartstapel = []    #Lege stapel met kaarten

def gif2num(s):     #hier gaat positie in, dus string van kaart
    kaart = []
    while s:
        for key in converter:
            if s.startswith(key):
                kaart.append(converter[key])
                s = s[len(key):]
                break
    return kaart      #dit spuugt lijst van waardes van de eigenschappen van de kaart uit

def kaartstapelmaker():
    kaartstapel.clear()
    for i in range(0,3):
        for j in range (0,3):
            for k in range (0,3):
                for l in range (0,3):
                    kaartstapel.append(kleur[i]+vorm[j]+vulling[k]+waarde[l]) #gaat combinaties van eigenschappen langs en gooit ze in de voorheen lege stapel

kaartstapelmaker()  #maakt alle kaarten aan en doet ze in een lijst

def uitdeel():
    n= 0
    while n <= 11:
        nummer = random.randint(0,len(kaartstapel)-1)   #pakt willekeurige kaart uit de stapel
        kaart = kaartstapel.pop(nummer)
        pos.append(kaart)
        n +=1

uitdeel()       #deelt initieel alle kaarten uit


def refill(n):
    global nog_geven
    nog_geven = True
    if len(kaartstapel)>0:                                  #checkt of kaartstapel nog kaarten heeft
        nieuw = random.randint(0,len(kaartstapel)-1)                #in geval ja maakt positie die kaart en haalt kaart uit stapel
        pos[n] = kaartstapel.pop(nieuw)
        
    else:
        pos[n] = 'leeg'
        pass                                               #stapel is leeg dus hij doet niks
    
    return pos[n]                                          #geeft de nieuwe kaart op positie n terug

def vind_alle_sets():
    npos = [gif2num(x) for x in pos] #converteerd de strings naar iets waar de functie iets mee kan
    antwoordenblad = SET_finder(npos)  #stelt het antwoorden blad op
    antwoordenblad = [[x+1 for x in antw] for antw in antwoordenblad]
    if len(antwoordenblad) == 0:
        return None
    return antwoordenblad

def SET_finder(invoer): #verwachte input is lijst van lijsten die kaarten representeren                                                                     #lege lijst waar sets in komen
    sets_in = []
    laatste = len(invoer)
    for i in range(0,laatste-2):  #gaat alle kaarten langs                                            
        for j in range(i+1,laatste-1):                                   #gaat alle kaarten erna langs
            for k in range(j+1,laatste):  
                for l in range(0,4):                                #gaat alle waardes van de kaarten langs
                    if invoer[i][l] + invoer[j][l] + invoer[k][l] in [0, 3 ,6]:    #checkt de waardes van de kaarten relatief tot elkaar
                        if l == 3:
                            sets_in.append([i,j,k])
                    else:
                        break                                                   #zorgt ervoor dat als een set al niet werkt vanaf de eerste waarde dat de checker niet de moeite neemt om de rest ook te checken
    return sets_in



def set_checker(lijst):
    nlijst = [gif2num(lijst[0]),gif2num(lijst[1]),gif2num(lijst[2])]
    flag = True
    global puntenspeler
    for l in range(0,4):
        if nlijst[0][l] + nlijst[1][l] + nlijst[2][l] not in [0, 3 ,6]: #gebruikt sum methode om te checken of set klopt
            flag = False
    if flag:
        
        puntenspeler += 1
        return True
    else:
        return False

def selectaanmaak(n):                       #maakt selectdict en hintdict aan met alles false zodat niks geselecteerd wordt
    selectdict.update({f"select{n}" : False})
    hintdict.update({f"{n}": False})
while selectint <= 13:
    selectaanmaak(selectint)
    selectint+=1

def geefhint():                             #geeft hint door random element uit random lijst te geven
    if vind_alle_sets() is not None:
        lijst = vind_alle_sets()
        rand1 = random.randint(0,len(lijst)-1)
        rand2 = random.randint(0,2)
        hint = lijst[rand1][rand2]
        hintdict.update({f"{hint}": True})      #voor visuele indicatie
    else:
        pass

def main_menu(): #main menu screen
    global run
    new_press = True
    while run:
        for event in pygame.event.get():    
            if event.type == pygame.QUIT:
                run = False                   #close game

        screen.blit(background, (0,0))                          #teken alle images
        screen.blit(title, (250, 50))
        start_button = Button(start_img, 250, 420, 0.5, True)
        exit_button = Button(exit_img, 550, 420, 0.5, True)
        htp_button = Button(htp, 450, 550, 0.5, True)
        pygame.display.set_icon(walt)
        if pygame.mouse.get_pressed()[0] and new_press:         #zorgt ervoor dat je 1x kan klikken
            new_press = False
            if start_button.check_click():                      #gaat naar main board
                diffselect()
            if exit_button.check_click():                       #sluit game af
                run = False
            if htp_button.check_click():
                tutorial()    
        if not pygame.mouse.get_pressed()[0] and not new_press: #klik reset voor enkele klik
            new_press = True

        pygame.display.update()             #refresh
        clock.tick(60)                      #framerate

def tutorial():
    global run
    new_press = True
    while run:
        for event in pygame.event.get():    
            if event.type == pygame.QUIT:
                run = False                   #close game
        screen.blit(tut, (0,0))
        home_btn = Button(home, 800, 500, 1 ,True)

        if pygame.mouse.get_pressed()[0] and new_press:         #zorgt ervoor dat je 1x kan klikken
            new_press = False    
            if home_btn.check_click():
                main_menu()
        
        if not pygame.mouse.get_pressed()[0] and not new_press: #klik reset voor enkele klik
            new_press = True


        pygame.display.update()             #refresh
        clock.tick(60)                      #framerate                                


def diffselect():   #scherm om moeilijkheidsgraad aan te passen
    global run
    new_press = True
    while run:
        for event in pygame.event.get():    
            if event.type == pygame.QUIT:
                run = False                   #close game
        
        screen.blit(background, (0,0))                          #teken alle images
        screen.blit(title, (250, 50))
        easy_knop = Button(easy, 100 ,420, 1, True)
        normal_knop = Button(normal, 400, 420, 1, True)
        hard_knop = Button(hard, 700, 420, 1, True)
        home_button = Button(home, 900, 550, 0.5, True)

        if pygame.mouse.get_pressed()[0] and new_press:         #zorgt ervoor dat je 1x kan klikken
            new_press = False
            if easy_knop.check_click():
                board(0.25)
            if normal_knop.check_click():
                board(0.5)
            if hard_knop.check_click():
                board(1)
            if home_button.check_click():
                main_menu()      

        if not pygame.mouse.get_pressed()[0] and not new_press: #klik reset voor enkele klik
            new_press = True
        
        
        pygame.display.update()             #refresh
        clock.tick(60)                      #framerate                    

def eindscherm(): #win/ lose screen
    global run                  #gebruik alle nodige global variabelen
    global puntenai         
    global puntenspeler
    global timx
    
    new_press = True
    
    while run: 
        for event in pygame.event.get():    
            if event.type == pygame.QUIT:
                run = False                   #close game
        
        screen.fill('Black')
        exit = Button(exit_img, 400, 420, 0.5, True)
        if puntenspeler > puntenai:                                     #display of je hebt gewonnen of verloren
            spelerwin = font.render('YOU WIN', True, 'White')
            screen.blit(spelerwin, (400,20))
        elif puntenspeler <= puntenai:
            cpuwin = font.render('YOU LOSE', True, 'White')   
            screen.blit(cpuwin, (400,20))   

        
        if pygame.mouse.get_pressed()[0] and new_press:         #zorgt ervoor dat je 1x kan klikken
            new_press = False
            if exit.check_click():                       #terug naar de main menu en reset alles
                run = False


       
        if not pygame.mouse.get_pressed()[0] and not new_press: #klik reset voor enkele klik
            new_press = True


        pygame.display.update()             #refresh
        clock.tick(60)                      #framerate


def board(diff):    #board screen
    global run
    new_press = True                #check of er een nieuwe press is, dan kan er geen dubble of triple click zijn
    global timx                     #positie rectangle timer
    global nog_geven
    global puntenspeler
    global puntenai
    global selectint
    puntenspeler = 0                #start met punten speler 0
    nog_geven = True                #bool of hint al gegeven is
    selectint = 1

    
    def selectaanmaak(n):
        selectdict.update({f"select{n}" : False})
    while selectint <= 12:
        selectaanmaak(selectint)
        selectint+=1
    
    
    def toggleselect(n):                                #selecteert of deselecteert bepaalde pos
        if selectdict[f"select{n}"] == False:
            selectdict.update({f"select{n}": True})
            selected.append(pos[n-1])
            insel.append(n-1)
            if len(selected) == 3:                      #als 3 geselecteerd check of het een set is
                if set_checker(selected):                       
                    refill(insel[0])
                    refill(insel[1])
                    refill(insel[2])
                    selected.clear()
                    insel.clear()
                    global timx
                    timx = 0
                    for n in range(0,13):
                        hintdict.update({f"{n}" : False})               #reset hint/selectdict
                        selectdict.update({f"select{n}": False})
        elif selectdict[f"select{n}"]:
            selectdict.update({f"select{n}": False})
            selected.remove(pos[n-1])
            insel.remove(n-1)
            if len(selected) == 3:                      #als 3 geselecteerd check of het een set is
                if set_checker(selected):                       
                    refill(insel[0])
                    refill(insel[1])
                    refill(insel[2])
                    selected.clear()
                    insel.clear()
                    timx = 0
                    for n in range(0,13):
                        hintdict.update({f"{n}" : False})               #reset hint/selectdict
                        selectdict.update({f"select{n}": False})
    
    while run:     
                
        for event in pygame.event.get():    
            if event.type == pygame.QUIT:
                run = False                   #close game
        
        timx -= diff            #snelheid van timer

        screen.blit(background, (0,0))        #background reload        
        timerrect = pygame.rect.Rect(timx, 0, 1000, 15)
        pygame.draw.rect(screen, 'Red', timerrect, width= 0)

        #button voor op bord
        pos1 = Button(cards[pos[0]], 75, 80, 1, True)       #alle kaarten op de juiste positie
        pos2 = Button(cards[pos[1]], 225, 80, 1, True)
        pos3 = Button(cards[pos[2]], 375, 80, 1, True)
        pos4 = Button(cards[pos[3]], 525, 80, 1, True)
        pos5 = Button(cards[pos[4]], 675, 80, 1, True)
        pos6 = Button(cards[pos[5]], 825, 80, 1, True)
        pos7 = Button(cards[pos[6]], 75, 320, 1, True)
        pos8 = Button(cards[pos[7]], 225, 320, 1, True)
        pos9 = Button(cards[pos[8]], 375, 320, 1, True)
        pos10 = Button(cards[pos[9]], 525, 320, 1, True)
        pos11 = Button(cards[pos[10]], 675, 320, 1, True)
        pos12 = Button(cards[pos[11]], 825, 320, 1, True)
        exit_button = Button(exit_img, 900, 550, 0.25, True) #rest van de knoppen
        hint_knop = Button(hintknop, 300, 550, 0.5, True)       
        cheat_knop = Button(cheatknop, 600, 550, 0.5, True)
        
        if timerrect.topright <= (0, 0):
            global puntenai
            vondst = vind_alle_sets()
            if len(kaartstapel)>0: #checkt of er nog kaarten zijn om de kaarten op tafel te vervangen
                if bool(vondst) != False:       #checkt of er sets aanwezig zijn
                    refill(vondst[0][0]-1)      #vervangt de set
                    refill(vondst[0][1]-1)
                    refill(vondst[0][2]-1)
                    timx = 0                    #reset de tijd
                    puntenai += 1                   #Geeft een punt aan de ai
                    selected.clear()
                    insel.clear()
                    for n in range(0,13):
                        hintdict.update({f"{n}" : False})               #reset hint/selectdict
                        selectdict.update({f"select{n}": False})
                else:                           #als er geen set is krijgt de ai geen punten en worden de eerste 3 kaarten vervangen
                    refill(0)
                    refill(1)
                    refill(2)
                    timx = 0
                    selected.clear()
                    insel.clear()
                    for n in range(0,13):
                        hintdict.update({f"{n}" : False})               #reset hint/selectdict
                        selectdict.update({f"select{n}": False})
            else:
                if bool(vondst) != False:       #checkt of er sets aanwezig zijn
                    refill(vondst[0][0]-1)      #vervangt de set
                    refill(vondst[0][1]-1)
                    refill(vondst[0][2]-1)
                    timx = 0                    #reset de tijd
                    puntenai += 1                   #Geeft een punt aan de ai
                    selected.clear()
                    insel.clear()
                    for n in range(0,13):
                        hintdict.update({f"{n}" : False})               #reset hint/selectdict
                        selectdict.update({f"select{n}": False})
                else:
                    eindscherm()
        
        cpuscore = font.render(f"{puntenai}", True, 'white')            #Score display
        cpurect = cpuscore.get_rect(midtop = (33,275))
        playerscore = font.render(f"{puntenspeler}", True, 'White')
        playerrect = playerscore.get_rect(midtop = (967,275))
        screen.blit(cpuscore, cpurect)
        screen.blit(playerscore, playerrect)        

        if pygame.mouse.get_pressed()[0] and new_press:     #check of geklikt wordt en zorgt ervoor dat er maar 1x geklikt wordt
            new_press = False
            if exit_button.check_click():
                run = False
            if pos1.check_click():
                toggleselect(1)
            if pos2.check_click():
                toggleselect(2)
            if pos3.check_click():
                toggleselect(3)
            if pos4.check_click():
                toggleselect(4)                                
            if pos5.check_click():
                toggleselect(5)
            if pos6.check_click():
                toggleselect(6)
            if pos7.check_click():
                toggleselect(7)
            if pos8.check_click():
                toggleselect(8)
            if pos9.check_click():
                toggleselect(9)
            if pos10.check_click():
                toggleselect(10)
            if pos11.check_click():
                toggleselect(11)
            if pos12.check_click():
                toggleselect(12)
            if hint_knop.check_click():
                if nog_geven:    
                    geefhint()
                    nog_geven = False
            if cheat_knop.check_click():
                print(vind_alle_sets())


        if not pygame.mouse.get_pressed()[0] and not new_press:     #zorgt ervoor dat er maar 1x geklikt wordt
            new_press = True
        

        if selectdict['select1']:
            screen.blit(slctbord, (67,72))          #select/ hint indicator en blit op de juiste posities
        if selectdict['select2']:
            screen.blit(slctbord, (217,72))
        if selectdict['select3']:
            screen.blit(slctbord, (367,72))
        if selectdict['select4']:
            screen.blit(slctbord, (517,72))
        if selectdict['select5']:
            screen.blit(slctbord, (667,72))
        if selectdict['select6']:
            screen.blit(slctbord, (817,72))
        if selectdict['select7']:
            screen.blit(slctbord, (67,312))
        if selectdict['select8']:
            screen.blit(slctbord, (217,312))
        if selectdict['select9']:
            screen.blit(slctbord, (367,312))        
        if selectdict['select10']:
            screen.blit(slctbord, (517,312))
        if selectdict['select11']:
            screen.blit(slctbord, (667,312))
        if selectdict['select12']:
            screen.blit(slctbord, (817,312))
        if hintdict['1']:
            screen.blit(hints['1'], (98,16))
        if hintdict['2']:
            screen.blit(hints['2'], (248,16))
        if hintdict['3']:
            screen.blit(hints['3'], (398,16))
        if hintdict['4']:
            screen.blit(hints['4'], (548,16))            
        if hintdict['5']:
            screen.blit(hints['5'], (698,16))
        if hintdict['6']:
            screen.blit(hints['6'], (848,16))
        if hintdict['7']:
            screen.blit(hints['7'], (98,536))
        if hintdict['8']:
            screen.blit(hints['8'], (248,536))
        if hintdict['9']:
            screen.blit(hints['9'], (398,536))
        if hintdict['10']:
            screen.blit(hints['10'], (548,536))
        if hintdict['11']:
            screen.blit(hints['11'], (698,536))
        if hintdict['12']:
            screen.blit(hints['12'], (848,536))           
        
        pygame.display.update()             #refresh
        clock.tick(60)                      #framerate


main_menu()
pygame.quit